// ClickSafeGD.cpp
// ClickSafe GD - proyecto base para Geode / Android.
// Esta versión implementa el menú y guarda la etapa seleccionada.
// Las etapas todavía NO automatizan entradas ni modifican la física del juego.

#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/ui/Popup.hpp>

using namespace geode::prelude;

namespace {
    constexpr int kDefaultStage = 1;

    class ClickSafePopup final : public Popup<> {
    protected:
        bool setup() override {
            setTitle("ClickSafe GD");

            const auto winSize = CCDirector::sharedDirector()->getWinSize();
            const int savedStage = Mod::get()->getSavedValue<int>("stage", kDefaultStage);

            auto info = CCLabelBMFont::create(
                "Choose your safety stage",
                "bigFont.fnt"
            );
            info->setScale(0.42f);
            info->setPosition({m_size.width / 2.f, m_size.height - 48.f});
            m_mainLayer->addChild(info);

            auto menu = CCMenu::create();
            menu->setPosition({m_size.width / 2.f, m_size.height / 2.f});
            m_mainLayer->addChild(menu);

            const char* names[] = {
                "Stage 1 - 30 Frames",
                "Stage 2 - 60 Frames",
                "Stage 3 - 90 Frames"
            };

            for (int i = 0; i < 3; ++i) {
                auto label = CCLabelBMFont::create(names[i], "goldFont.fnt");
                auto button = CCMenuItemLabel::create(
                    label,
                    [i](CCObject*) {
                        const int selectedStage = i + 1;
                        Mod::get()->setSavedValue<int>("stage", selectedStage);

                        FLAlertLayer::create(
                            "ClickSafe GD",
                            fmt::format(
                                "Stage {} selected ({} frames).",
                                selectedStage,
                                selectedStage * 30
                            ),
                            "OK"
                        )->show();
                    }
                );

                button->setScale(0.48f);
                button->setPosition({0.f, 30.f - static_cast<float>(i) * 38.f});
                menu->addChild(button);
            }

            auto closeLabel = CCLabelBMFont::create("X", "bigFont.fnt");
            auto closeButton = CCMenuItemLabel::create(
                closeLabel,
                this,
                menu_selector(ClickSafePopup::onClose)
            );
            closeButton->setScale(0.55f);
            closeButton->setPosition({
                m_size.width - 20.f,
                m_size.height - 20.f
            });

            auto closeMenu = CCMenu::create();
            closeMenu->setPosition({0.f, 0.f});
            closeMenu->addChild(closeButton);
            m_mainLayer->addChild(closeMenu);

            // El valor se lee para asegurar que la selección guardada sea válida.
            if (savedStage < 1 || savedStage > 3) {
                Mod::get()->setSavedValue<int>("stage", kDefaultStage);
            }

            return true;
        }

    public:
        static ClickSafePopup* create() {
            auto ret = new ClickSafePopup();
            if (ret && ret->initAnchored(280.f, 220.f)) {
                ret->autorelease();
                return ret;
            }
            CC_SAFE_DELETE(ret);
            return nullptr;
        }
    };
}

// Añade un acceso al menú principal para que el popup se pueda abrir.
class $modify(ClickSafeMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) {
            return false;
        }

        const auto winSize = CCDirector::sharedDirector()->getWinSize();

        auto label = CCLabelBMFont::create("ClickSafe", "goldFont.fnt");
        auto button = CCMenuItemLabel::create(
            label,
            [](CCObject*) {
                if (auto popup = ClickSafePopup::create()) {
                    popup->show();
                }
            }
        );
        button->setScale(0.48f);

        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        button->setPosition({winSize.width - 62.f, winSize.height * 0.52f});
        menu->addChild(button);
        this->addChild(menu, 100);

        return true;
    }
};

$on_mod(Loaded) {
    log::info("ClickSafe GD loaded!");
}
