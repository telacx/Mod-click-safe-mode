# ClickSafe GD

A small starting point for a Geometry Dash Geode mod that exposes a stage-selection popup.

Current stages are configuration labels only. Recording/replaying player input is not implemented in this version.
