# ClickSafe GD — Android project source

This is a **source project**, not a compiled `.geode` file.

## Included in this version
- Adds a `ClickSafe` button to the Geometry Dash main menu.
- Opens a popup with Stage 1 / 2 / 3.
- Saves the selected stage in Geode's saved values.
- Targets Android Geometry Dash `2.2074` and Geode core `v4.10.2` in `mod.json`.

## Important limitation
The stage values (30/60/90 frames) are currently labels/settings only. They do not yet record or replay inputs, alter gameplay, or provide a macro engine.

## Build on a computer with Geode CLI and Android NDK installed

1. Install the Geode CLI and a compatible Android NDK.
2. Set `ANDROID_NDK_ROOT` to the NDK directory.
3. Install Geode's Android SDK binaries:
   - 64-bit Android: `geode sdk install-binaries -p android64`
   - 32-bit Android: `geode sdk install-binaries -p android32`
4. From this project directory, run one of:
   - `geode build -p android64`
   - `geode build -p android32`
5. If the build succeeds, look for the `.geode` file in `build-android64` or `build-android32`.
6. Copy the generated `.geode` file to the Geode mods folder on the device:
   `/storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/`

## Version compatibility warning
Geode's build checks compare the target Geode version and target Geometry Dash version against the installed SDK binaries. The Android launcher version (for example, `1.8.0`) is not necessarily the Geode core/SDK version in `mod.json`. The project currently targets Geode core `v4.10.2`, reported as compatible with GD `2.2074`. The build must still be run against SDK binaries that match your actual game/Geode installation; if your installed core differs, update `geode` to the exact SDK version and verify the target GD version before compiling. Do not guess this field.

Official build instructions:
https://github.com/geode-sdk/docs/blob/main/getting-started/create-mod.md


## Cloud build from a phone (GitHub Actions)

The project includes `.github/workflows/android.yml`.

1. Sign in to GitHub and create a new repository for this project.
2. Upload the **contents** of this ZIP (including the hidden `.github` folder) to the repository. If uploading via the GitHub mobile website, ensure `.github/workflows/android.yml` is created at that exact path; some mobile upload flows hide dot-folders.
3. Open the repository's **Actions** tab and select **Build ClickSafe GD for Android**.
4. Tap **Run workflow** (or push a commit to the `main` branch to trigger it).
5. When the run finishes successfully, open that run and download the `ClickSafeGD-Android64` artifact. It should contain the generated `.geode` package.

This workflow builds Android 64-bit only. If the build fails, inspect the failed step's logs; the likely causes include SDK/version mismatch or C++ API errors. A successful CI build still needs testing in Geometry Dash before considering the mod verified.

Note: GitHub Actions may require confirming an email address or enabling Actions for the repository. Never share your GitHub password or access token in chat.
