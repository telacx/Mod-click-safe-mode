# Changelog

## v1.0.0
- Added a main-menu entry for the ClickSafe popup.
- Added three selectable stages.
- Persisted the selected stage using Geode saved values.
